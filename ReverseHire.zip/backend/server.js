import "dotenv/config";
import cors from "cors";
import express from "express";
import candidateRoutes from "./routes/candidateRoutes.js";
import companyRoutes from "./routes/companyRoutes.js";
import opportunityRoutes from "./routes/opportunityRoutes.js";
import postRoutes from "./routes/postRoutes.js";
import { errorHandler, notFound } from "./middleware/errorHandler.js";

const app = express();
const port = Number(process.env.PORT) || 5000;

app.use(
  cors({
    origin: process.env.CLIENT_URL?.split(",").map((origin) => origin.trim()) ?? true,
  }),
);
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => {
  res.json({
    success: true,
    data: {
      status: "ok",
      storage: "in-memory",
      message: "MongoDB can be added later without changing the API contract.",
    },
  });
});

app.use("/api/candidates", candidateRoutes);
app.use("/api/companies", companyRoutes);
app.use("/api/opportunities", opportunityRoutes);
app.use("/api/posts", postRoutes);

app.use(notFound);
app.use(errorHandler);

app.listen(port, () => {
  console.log(`ReverseHire API running at http://localhost:${port}`);
  console.log("Storage mode: in-memory seeded data (MongoDB not configured)");
});

export default app;
