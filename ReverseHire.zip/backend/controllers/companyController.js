import { store } from "../store/dataStore.js";
import { cleanString, validateCompany } from "../utils/validation.js";

const fields = [
  "name",
  "description",
  "industry",
  "location",
  "website",
  "companySize",
];

const pickFields = (body) =>
  fields.reduce((result, field) => {
    if (body[field] !== undefined) result[field] = cleanString(body[field]);
    return result;
  }, {});

const sendValidationError = (res, errors) =>
  res.status(400).json({ success: false, message: "Please fix the highlighted fields", errors });

export function listCompanies(_req, res) {
  res.json({ success: true, data: store.list("companies") });
}

export function getCompany(req, res) {
  const company = store.findById("companies", req.params.id);
  if (!company) {
    return res.status(404).json({ success: false, message: "Company not found" });
  }
  return res.json({ success: true, data: company });
}

export function createCompany(req, res) {
  const data = pickFields(req.body);
  const errors = validateCompany(data);
  if (errors.length) return sendValidationError(res, errors);

  return res.status(201).json({ success: true, data: store.insert("companies", data) });
}

export function updateCompany(req, res) {
  const existing = store.findById("companies", req.params.id);
  if (!existing) {
    return res.status(404).json({ success: false, message: "Company not found" });
  }

  const data = { ...existing, ...pickFields(req.body) };
  const errors = validateCompany(data);
  if (errors.length) return sendValidationError(res, errors);

  return res.json({
    success: true,
    data: store.update("companies", req.params.id, pickFields(data)),
  });
}

export function deleteCompany(req, res) {
  const deleted = store.remove("companies", req.params.id);
  if (!deleted) {
    return res.status(404).json({ success: false, message: "Company not found" });
  }

  store
    .list("opportunities")
    .filter((opportunity) => opportunity.company === req.params.id)
    .forEach((opportunity) => store.remove("opportunities", opportunity.id));

  return res.status(204).send();
}
