import { store } from "../store/dataStore.js";
import {
  cleanString,
  validateOpportunity,
} from "../utils/validation.js";

const editableFields = [
  "candidate",
  "company",
  "roleTitle",
  "description",
  "location",
  "workMode",
  "compensation",
  "message",
];

const pickFields = (body) =>
  editableFields.reduce((result, field) => {
    if (body[field] !== undefined) result[field] = cleanString(body[field]);
    return result;
  }, {});

const sendValidationError = (res, errors) =>
  res.status(400).json({ success: false, message: "Please fix the highlighted fields", errors });

const populate = (opportunity) => {
  if (!opportunity) return null;

  const candidate = store.findById("candidates", opportunity.candidate);
  const company = store.findById("companies", opportunity.company);

  return {
    ...opportunity,
    candidate: candidate
      ? {
          id: candidate.id,
          name: candidate.name,
          headline: candidate.headline,
          location: candidate.location,
        }
      : opportunity.candidate,
    company: company
      ? {
          id: company.id,
          name: company.name,
          industry: company.industry,
          location: company.location,
        }
      : opportunity.company,
  };
};

const getStoredOpportunity = (id) => store.findById("opportunities", id);

const ensureReferences = (data) => {
  const errors = [];
  if (!store.findById("candidates", data.candidate)) errors.push("candidate does not exist");
  if (!store.findById("companies", data.company)) errors.push("company does not exist");
  return errors;
};

export function listOpportunities(req, res) {
  const { candidateId, companyId, status } = req.query;
  let opportunities = store.list("opportunities");

  if (candidateId) {
    opportunities = opportunities.filter((item) => item.candidate === candidateId);
  }
  if (companyId) {
    opportunities = opportunities.filter((item) => item.company === companyId);
  }
  if (status) {
    opportunities = opportunities.filter((item) => item.status === status.toUpperCase());
  }

  opportunities.sort((first, second) => second.createdAt.localeCompare(first.createdAt));
  return res.json({ success: true, data: opportunities.map(populate) });
}

export function getOpportunity(req, res) {
  const opportunity = populate(getStoredOpportunity(req.params.id));
  if (!opportunity) {
    return res.status(404).json({ success: false, message: "Opportunity not found" });
  }
  return res.json({ success: true, data: opportunity });
}

export function createOpportunity(req, res) {
  const data = pickFields(req.body);
  const errors = [...validateOpportunity(data), ...ensureReferences(data)];
  if (errors.length) return sendValidationError(res, errors);

  const created = store.insert("opportunities", {
    ...data,
    status: "PENDING",
    respondedAt: null,
  });

  return res.status(201).json({ success: true, data: populate(created) });
}

export function updateOpportunity(req, res) {
  const existing = getStoredOpportunity(req.params.id);
  if (!existing) {
    return res.status(404).json({ success: false, message: "Opportunity not found" });
  }
  if (existing.status !== "PENDING") {
    return res.status(409).json({
      success: false,
      message: "Only pending opportunities can be edited",
    });
  }

  const data = { ...existing, ...pickFields(req.body) };
  const errors = [...validateOpportunity(data), ...ensureReferences(data)];
  if (errors.length) return sendValidationError(res, errors);

  return res.json({
    success: true,
    data: populate(store.update("opportunities", req.params.id, pickFields(data))),
  });
}

export function deleteOpportunity(req, res) {
  const deleted = store.remove("opportunities", req.params.id);
  if (!deleted) {
    return res.status(404).json({ success: false, message: "Opportunity not found" });
  }
  return res.status(204).send();
}

function setStatus(req, res, status) {
  const existing = getStoredOpportunity(req.params.id);
  if (!existing) {
    return res.status(404).json({ success: false, message: "Opportunity not found" });
  }
  if (existing.status !== "PENDING") {
    return res.status(409).json({
      success: false,
      message: "This opportunity has already been answered",
    });
  }

  const updated = store.update("opportunities", req.params.id, {
    status,
    respondedAt: new Date().toISOString(),
  });

  return res.json({ success: true, data: populate(updated) });
}

export const acceptOpportunity = (req, res) => setStatus(req, res, "ACCEPTED");
export const declineOpportunity = (req, res) => setStatus(req, res, "DECLINED");
