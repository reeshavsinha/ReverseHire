import { randomUUID } from "node:crypto";
import { store } from "../store/dataStore.js";
import {
  cleanString,
  validateComment,
  validatePost,
} from "../utils/validation.js";

const postFields = [
  "type",
  "content",
  "mediaUrl",
  "mediaType",
  "projectTitle",
  "projectStatus",
  "projectUrl",
];

const pickPostFields = (body) =>
  postFields.reduce((result, field) => {
    if (body[field] !== undefined) result[field] = cleanString(body[field]);
    return result;
  }, {});

const validationError = (res, errors) =>
  res.status(400).json({
    success: false,
    message: "Please fix the highlighted fields",
    errors,
  });

const findPost = (id) => store.findById("posts", id);

const authorSummary = (authorId) => {
  const candidate = store.findById("candidates", authorId);
  if (!candidate) return { id: authorId, name: "Unknown candidate" };
  return {
    id: candidate.id,
    name: candidate.name,
    headline: candidate.headline,
    profilePhotoUrl: candidate.profilePhotoUrl || "",
  };
};

const populatePost = (post, viewerId = "") => {
  if (!post) return null;
  return {
    ...post,
    author: authorSummary(post.authorId),
    comments: (post.comments || []).map((comment) => ({
      ...comment,
      author: authorSummary(comment.authorId),
    })),
    reactionCount: (post.reactions || []).length,
    commentCount: (post.comments || []).length,
    viewerReaction:
      (post.reactions || []).find((reaction) => reaction.candidateId === viewerId)?.type ||
      null,
  };
};

const ensureCandidate = (candidateId) =>
  Boolean(candidateId && store.findById("candidates", candidateId));

export function listPosts(req, res) {
  const { authorId, type, viewerId } = req.query;
  let posts = store.list("posts");

  if (authorId) posts = posts.filter((post) => post.authorId === authorId);
  if (type) posts = posts.filter((post) => post.type === type.toUpperCase());

  posts.sort((first, second) => second.createdAt.localeCompare(first.createdAt));
  return res.json({
    success: true,
    data: posts.map((post) => populatePost(post, viewerId)),
  });
}

export function getPost(req, res) {
  const post = populatePost(findPost(req.params.id), req.query.viewerId);
  if (!post) {
    return res.status(404).json({ success: false, message: "Post not found" });
  }
  return res.json({ success: true, data: post });
}

export function createPost(req, res) {
  const data = {
    type: "TEXT",
    mediaUrl: "",
    mediaType: "",
    projectTitle: "",
    projectStatus: "",
    projectUrl: "",
    comments: [],
    reactions: [],
    ...pickPostFields(req.body),
    authorId: cleanString(req.body.authorId),
  };
  const errors = validatePost(data);
  if (!ensureCandidate(data.authorId)) errors.push("authorId must belong to a candidate");
  if (errors.length) return validationError(res, errors);

  const created = store.insert("posts", data);
  return res.status(201).json({
    success: true,
    data: populatePost(created, data.authorId),
  });
}

export function updatePost(req, res) {
  const existing = findPost(req.params.id);
  if (!existing) {
    return res.status(404).json({ success: false, message: "Post not found" });
  }

  const actorId = cleanString(req.body.actorId);
  if (actorId !== existing.authorId) {
    return res.status(403).json({ success: false, message: "Only the post author can edit it" });
  }

  const data = {
    ...existing,
    ...pickPostFields(req.body),
    authorId: existing.authorId,
  };
  const errors = validatePost(data);
  if (errors.length) return validationError(res, errors);

  return res.json({
    success: true,
    data: populatePost(store.update("posts", existing.id, pickPostFields(data)), actorId),
  });
}

export function deletePost(req, res) {
  const existing = findPost(req.params.id);
  if (!existing) {
    return res.status(404).json({ success: false, message: "Post not found" });
  }

  const actorId = cleanString(req.query.actorId);
  if (actorId !== existing.authorId) {
    return res.status(403).json({ success: false, message: "Only the post author can delete it" });
  }

  store.remove("posts", existing.id);
  return res.status(204).send();
}

export function addComment(req, res) {
  const post = findPost(req.params.id);
  if (!post) {
    return res.status(404).json({ success: false, message: "Post not found" });
  }

  const data = {
    candidateId: cleanString(req.body.candidateId),
    body: cleanString(req.body.body),
  };
  const errors = validateComment(data);
  if (!ensureCandidate(data.candidateId)) errors.push("candidateId must belong to a candidate");
  if (errors.length) return validationError(res, errors);

  const comment = {
    id: `comment-${randomUUID().slice(0, 8)}`,
    authorId: data.candidateId,
    body: data.body,
    createdAt: new Date().toISOString(),
  };
  const updated = store.update("posts", post.id, {
    comments: [...(post.comments || []), comment],
  });

  return res.status(201).json({
    success: true,
    data: populatePost(updated, data.candidateId),
  });
}

export function deleteComment(req, res) {
  const post = findPost(req.params.id);
  if (!post) {
    return res.status(404).json({ success: false, message: "Post not found" });
  }

  const actorId = cleanString(req.query.candidateId);
  const comment = (post.comments || []).find((item) => item.id === req.params.commentId);
  if (!comment) {
    return res.status(404).json({ success: false, message: "Comment not found" });
  }
  if (comment.authorId !== actorId) {
    return res.status(403).json({ success: false, message: "Only the comment author can delete it" });
  }

  const updated = store.update("posts", post.id, {
    comments: post.comments.filter((item) => item.id !== comment.id),
  });
  return res.json({ success: true, data: populatePost(updated, actorId) });
}

export function toggleReaction(req, res) {
  const post = findPost(req.params.id);
  if (!post) {
    return res.status(404).json({ success: false, message: "Post not found" });
  }

  const candidateId = cleanString(req.body.candidateId);
  const type = cleanString(req.body.type || "LIKE").toUpperCase();
  if (!ensureCandidate(candidateId)) {
    return validationError(res, ["candidateId must belong to a candidate"]);
  }
  if (!["LIKE", "CELEBRATE", "INSIGHTFUL"].includes(type)) {
    return validationError(res, ["type must be LIKE, CELEBRATE, or INSIGHTFUL"]);
  }

  const existing = (post.reactions || []).find(
    (reaction) => reaction.candidateId === candidateId,
  );
  let reactions = post.reactions || [];
  if (existing?.type === type) {
    reactions = reactions.filter((reaction) => reaction.candidateId !== candidateId);
  } else if (existing) {
    reactions = reactions.map((reaction) =>
      reaction.candidateId === candidateId ? { ...reaction, type } : reaction,
    );
  } else {
    reactions = [...reactions, { candidateId, type }];
  }

  const updated = store.update("posts", post.id, { reactions });
  return res.json({ success: true, data: populatePost(updated, candidateId) });
}
