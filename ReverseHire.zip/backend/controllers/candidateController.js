import { store } from "../store/dataStore.js";
import {
  cleanString,
  cleanStringList,
  cleanExperience,
  cleanProjects,
  validateCandidate,
} from "../utils/validation.js";
import { randomUUID } from "node:crypto";

const fields = [
  "name",
  "headline",
  "about",
  "skills",
  "education",
  "location",
  "preferredWorkMode",
  "preferredRoles",
  "availability",
  "portfolioUrl",
  "githubUrl",
  "profilePhotoUrl",
  "coverPhotoUrl",
  "pronouns",
  "experience",
  "projects",
  "featuredPostIds",
];

const pickFields = (body) =>
  fields.reduce((result, field) => {
    if (body[field] !== undefined) {
      if (field === "experience") {
        result[field] = cleanExperience(body[field]).map((item) => ({
          ...item,
          id: item.id || `experience-${randomUUID().slice(0, 8)}`,
        }));
      } else if (field === "projects") {
        result[field] = cleanProjects(body[field]).map((item) => ({
          ...item,
          id: item.id || `project-${randomUUID().slice(0, 8)}`,
        }));
      } else {
        result[field] = Array.isArray(body[field])
          ? cleanStringList(body[field])
          : cleanString(body[field]);
      }
    }
    return result;
  }, {});

const sendValidationError = (res, errors) =>
  res.status(400).json({ success: false, message: "Please fix the highlighted fields", errors });

export function listCandidates(req, res) {
  const { skill, role, location } = req.query;
  let candidates = store.list("candidates");

  if (skill) {
    const query = skill.toLowerCase();
    candidates = candidates.filter((candidate) =>
      candidate.skills.some((item) => item.toLowerCase().includes(query)),
    );
  }
  if (role) {
    const query = role.toLowerCase();
    candidates = candidates.filter((candidate) =>
      candidate.preferredRoles.some((item) => item.toLowerCase().includes(query)),
    );
  }
  if (location) {
    const query = location.toLowerCase();
    candidates = candidates.filter((candidate) =>
      candidate.location.toLowerCase().includes(query),
    );
  }

  res.json({ success: true, data: candidates });
}

export function getCandidate(req, res) {
  const candidate = store.findById("candidates", req.params.id);
  if (!candidate) {
    return res.status(404).json({ success: false, message: "Candidate not found" });
  }
  return res.json({ success: true, data: candidate });
}

export function createCandidate(req, res) {
  const data = {
    experience: [],
    projects: [],
    featuredPostIds: [],
    ...pickFields(req.body),
  };
  const errors = validateCandidate(data);
  if (errors.length) return sendValidationError(res, errors);

  return res.status(201).json({ success: true, data: store.insert("candidates", data) });
}

export function updateCandidate(req, res) {
  const existing = store.findById("candidates", req.params.id);
  if (!existing) {
    return res.status(404).json({ success: false, message: "Candidate not found" });
  }

  const data = { ...existing, ...pickFields(req.body) };
  const errors = validateCandidate(data);
  if (errors.length) return sendValidationError(res, errors);

  return res.json({
    success: true,
    data: store.update("candidates", req.params.id, pickFields(data)),
  });
}

export function deleteCandidate(req, res) {
  const deleted = store.remove("candidates", req.params.id);
  if (!deleted) {
    return res.status(404).json({ success: false, message: "Candidate not found" });
  }

  store
    .list("opportunities")
    .filter((opportunity) => opportunity.candidate === req.params.id)
    .forEach((opportunity) => store.remove("opportunities", opportunity.id));

  return res.status(204).send();
}
