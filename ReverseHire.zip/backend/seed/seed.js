import { store } from "../store/dataStore.js";

store.reset();

console.log("ReverseHire in-memory seed loaded.");
console.log(`Candidates: ${store.list("candidates").length}`);
console.log(`Companies: ${store.list("companies").length}`);
console.log(`Opportunities: ${store.list("opportunities").length}`);
console.log(`Posts: ${store.list("posts").length}`);
console.log("Note: the running API seeds itself on startup; MongoDB is not required.");
