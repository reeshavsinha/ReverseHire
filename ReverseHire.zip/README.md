# ReverseHire

ReverseHire is a small reverse-recruitment MVP: candidates create profiles, companies discover them, and companies send opportunities directly to candidates.

## Current storage mode

This first implementation intentionally does **not** require MongoDB. The Express API uses an in-memory store populated with demonstration data on every server start. The API shape is kept stable so MongoDB/Mongoose can be added later behind the same controllers and routes.

Because authentication is intentionally out of scope, the navigation includes a **Demo as** switcher. It lets you switch between seeded candidate and company profiles and stores that choice in `localStorage`.

## Prerequisites

- Node.js LTS
- npm
- Git
- A modern browser

MongoDB is not required for this version.

## Run locally

From the project root:

```powershell
npm install
npm run install:all
npm run dev
```

The frontend runs at `http://localhost:5173` and the API runs at `http://localhost:5000`.

To run either side separately:

```powershell
npm run dev --prefix backend
npm run dev --prefix frontend
```

The API health check is available at `http://localhost:5000/api/health`.

To inspect the seed command:

```powershell
npm run seed --prefix backend
```

## API

### Candidates

```text
GET    /api/candidates?skill=&role=&location=
GET    /api/candidates/:id
POST   /api/candidates
PUT    /api/candidates/:id
DELETE /api/candidates/:id
```

### Companies

```text
GET    /api/companies
GET    /api/companies/:id
POST   /api/companies
PUT    /api/companies/:id
DELETE /api/companies/:id
```

### Opportunities

```text
GET    /api/opportunities?candidateId=&companyId=&status=
GET    /api/opportunities/:id
POST   /api/opportunities
PUT    /api/opportunities/:id
DELETE /api/opportunities/:id
PATCH  /api/opportunities/:id/accept
PATCH  /api/opportunities/:id/decline
```

### Candidate community

```text
GET    /api/posts?authorId=&type=&viewerId=
GET    /api/posts/:id?viewerId=
POST   /api/posts
PUT    /api/posts/:id
DELETE /api/posts/:id?actorId=
POST   /api/posts/:id/comments
DELETE /api/posts/:id/comments/:commentId?candidateId=
PATCH  /api/posts/:id/reactions
```

The social layer is candidate-only in the UI. Candidates can publish thoughts, project updates, and hosted video links; comment and react to community posts; and view their own activity on their profile. Companies can browse candidate profiles but do not get social posting controls.

## Seeded demo data

The in-memory store includes:

- 5 candidates
- 3 companies
- 6 opportunities
- 6 social posts with comments and reactions

Data resets to this seed whenever the backend restarts.

## MongoDB follow-up

When MongoDB is available:

1. Add `mongoose` and a `MONGODB_URI` environment variable to the backend.
2. Add Mongoose schemas for Candidate, Company, Opportunity, and Post in `backend/models/`.
3. Replace the methods in `backend/store/dataStore.js` with a repository backed by Mongoose.
4. Keep the existing controller response shapes and frontend API service unchanged.
5. Convert the seed data into a repeatable database seed command.
6. Preserve the embedded comment/reaction shape or split those arrays into collections only if production-scale querying requires it.

## Documentation

- [Architecture](docs/architecture.md)
- [Development setup](docs/setup.md)
- [REST API reference](docs/api.md)
- [Data models](docs/data-models.md)
- [Candidate social features](docs/social-features.md)
- [MongoDB migration plan](docs/mongodb-migration.md)

## Main pages

- Landing page
- Candidate discovery and profile
- Candidate Community feed with project/video updates
- Company profile
- Candidate dashboard, profile editor, profile activity, and inbox
- Company dashboard, profile editor, create opportunity, and sent opportunities

